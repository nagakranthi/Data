//
//  ViewController.swift
//  CoreData Sample
//
//  Created by chandra sekhar p on 19/11/18.
//  Copyright © 2018 chandra sekhar p. All rights reserved.
//

import UIKit
import  CoreData

typealias JSONDictionary = [String: Any]

class ViewController: UIViewController {
    
    lazy var masterData: JSONDictionary = jsonFile()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    lazy var context = appDelegate.persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        saveInfoIntoCoreData()
        getBillersByCategory(category: "Electricity")
    }
}

//MARK: CORE DATA OPERATIONS
extension ViewController{
    fileprivate func saveInfoIntoCoreData(){
        if let billerList = self.billersList(){
            deleteRecords()
            for billerJson in billerList{
                let biller = BillersList(context: context)
                biller.billerName = billerJson["billerName"] as? String
                biller.category = billerJson["category"] as? String
                if let billerCategoryJson = self.billerCategoryByCategoryName(categoryName: billerJson["category"] as? String){
                    let billerPosition = BillersPositionList(context: context)
                    billerPosition.billerSubCategory = billerCategoryJson["billerSubCategory"] as? String
                    biller.billerPosition = billerPosition
                }
            }
        }
    }
    
    private func deleteRecords(){
        let fetchRequest: NSFetchRequest<BillersList> = NSFetchRequest(entityName: String(describing: BillersList.self))
        do {
            let records = try context.fetch(fetchRequest)
            for record in records {
                context.delete(record)
            }
            saveContext()
        } catch {
            print(error)
        }
        
    }
    
    func getBillersByCategory(category: String){
        let predicate = NSPredicate(format: "category == %@", category)
        let fetchRequest: NSFetchRequest<BillersList> = NSFetchRequest(entityName: String(describing: BillersList.self))
        fetchRequest.predicate = predicate
        do {
            let records = try context.fetch(fetchRequest)
            
            for record in records {
                print(record.billerName ?? "Name can't be nil")
                print("category object:\(record.billerPosition?.billerSubCategory ?? "Category can't be nil")")
            }
            
        } catch {
            print(error)
        }
    }
    
    private func saveContext() {
        do {
            try context.save()
        } catch {
            print("Failed saving")
        }
    }
    
    private func billersList() -> [JSONDictionary]?{
        return masterData["billerDelts"] as? [JSONDictionary]
    }
    
    private func billerCategoryByCategoryName(categoryName: String?) -> JSONDictionary?{
        
        if let data = self.masterData["billerPositionDetls"] as? [JSONDictionary]{
            return data.filter({$0["billerSubCategory"] as? String == categoryName}).first
        }
        return nil
    }
}

//MARK: HELPERS
extension ViewController{
    fileprivate func jsonFile() -> JSONDictionary{
        if let path = Bundle.main.path(forResource: "data", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? JSONDictionary, let _ = jsonResult["billerPositionDetls"] as? [Any] {
                    print("\(data)")
                    return jsonResult
                }
            } catch {
                print("Json parse error")
            }
        }
        return ["data": "no such json file found"]
    }
}

